﻿using System;
using System.Windows;

namespace WPFRegisterStudent
{
    public partial class MainWindow : Window
    {
        private Course choice;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Initialize courses
            Course course1 = new Course("IT 145");
            Course course2 = new Course("IT 200");
            Course course3 = new Course("IT 201");
            Course course4 = new Course("IT 270");
            Course course5 = new Course("IT 315");
            Course course6 = new Course("IT 328");
            Course course7 = new Course("IT 330");

            // Add courses to ComboBox
            comboBox.Items.Add(course1);
            comboBox.Items.Add(course2);
            comboBox.Items.Add(course3);
            comboBox.Items.Add(course4);
            comboBox.Items.Add(course5);
            comboBox.Items.Add(course6);
            comboBox.Items.Add(course7);

            // Clear text boxes
            textBoxCreditHours.Text = "";
            textBoxCreditHours.Text = "0";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Validate if a course is selected
            if (comboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a course to register.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            choice = (Course)comboBox.SelectedItem;

            // Check if the course is already registered
            if (choice.IsRegisteredAlready())
            {
                MessageBox.Show("You are already registered for this course.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Check if registering this course will exceed credit hours limit (9 credit hours)
            int totalCreditHours = CalculateTotalCreditHours();
            if (totalCreditHours + 3 > 9)
            {
                MessageBox.Show("You cannot register for more than 9 credit hours.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // If all validations pass, register the course
            choice.SetToRegistered();

            // Update UI: Add the course to the listBox and update total credit hours textbox
            listBox.Items.Add(choice.GetName());
            textBoxCreditHours.Text = CalculateTotalCreditHours().ToString();

            MessageBox.Show("Registration confirmed for " + choice.GetName(), "Registration Confirmation", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private int CalculateTotalCreditHours()
        {
            int totalCreditHours = 0;

            // Iterate through each course to calculate total credit hours
            foreach (var item in comboBox.Items)
            {
                Course course = (Course)item;
                if (course.IsRegisteredAlready())
                {
                    totalCreditHours += 3;
                }
            }

            return totalCreditHours;
        }
    }
}